# opencv
Basic openCV codes to to recognise faces using cascade using machine learning.
